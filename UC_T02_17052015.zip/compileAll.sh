
echo "Algo"
javac -encoding UTF8 SistemaA/*.java
javac -encoding UTF8 SistemaB/*.java
javac -encoding UTF8 SistemaC/*.java